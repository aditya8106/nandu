import React from 'react';
import { TouchableOpacity, View, Text, StyleSheet } from 'react-native';
import { Service } from '@/types';
import { Colors } from '@/constants/Colors';
import { Zap, Wrench, Hammer, Wind, Sparkles, Palette } from 'lucide-react-native';

const iconMap = {
  zap: Zap,
  wrench: Wrench,
  hammer: Hammer,
  wind: Wind,
  sparkles: Sparkles,
  palette: Palette,
};

interface ServiceCardProps {
  service: Service;
  onPress: () => void;
}

export default function ServiceCard({ service, onPress }: ServiceCardProps) {
  const IconComponent = iconMap[service.icon as keyof typeof iconMap] || Zap;

  return (
    <TouchableOpacity style={styles.card} onPress={onPress} activeOpacity={0.7}>
      <View style={styles.iconContainer}>
        <IconComponent size={28} color={Colors.primary} strokeWidth={2} />
      </View>
      <Text style={styles.name}>{service.name}</Text>
      <Text style={styles.description}>{service.description}</Text>
      <Text style={styles.price}>From ₹{service.basePrice}</Text>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: Colors.white,
    borderRadius: 16,
    padding: 20,
    marginBottom: 16,
    shadowColor: Colors.black,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
    borderWidth: 1,
    borderColor: Colors.gray100,
  },
  iconContainer: {
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: Colors.gray50,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 12,
  },
  name: {
    fontSize: 18,
    fontFamily: 'Poppins-SemiBold',
    color: Colors.textPrimary,
    marginBottom: 8,
  },
  description: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: Colors.textSecondary,
    marginBottom: 12,
    lineHeight: 20,
  },
  price: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: Colors.primary,
  },
});