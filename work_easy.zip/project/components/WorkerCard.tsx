import React from 'react';
import { TouchableOpacity, View, Text, StyleSheet, Image } from 'react-native';
import { Worker } from '@/types';
import { Colors } from '@/constants/Colors';
import { Star, MapPin, Shield, Clock } from 'lucide-react-native';

interface WorkerCardProps {
  worker: Worker;
  onPress: () => void;
  distance?: number;
}

export default function WorkerCard({ worker, onPress, distance }: WorkerCardProps) {
  return (
    <TouchableOpacity style={styles.card} onPress={onPress} activeOpacity={0.7}>
      <View style={styles.header}>
        <View style={styles.avatarContainer}>
          <Image
            source={{ uri: worker.avatar || 'https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&fit=crop' }}
            style={styles.avatar}
          />
          {worker.verified && (
            <View style={styles.verifiedBadge}>
              <Shield size={12} color={Colors.white} strokeWidth={2} />
            </View>
          )}
        </View>
        
        <View style={styles.info}>
          <Text style={styles.name}>{worker.name}</Text>
          <View style={styles.ratingContainer}>
            <Star size={14} color={Colors.accent} fill={Colors.accent} strokeWidth={0} />
            <Text style={styles.rating}>{worker.rating.toFixed(1)}</Text>
            <Text style={styles.jobCount}>({worker.totalJobs} jobs)</Text>
          </View>
          <View style={styles.locationContainer}>
            <MapPin size={14} color={Colors.textSecondary} strokeWidth={2} />
            <Text style={styles.location}>
              {distance ? `${distance.toFixed(1)} km away` : worker.location.address}
            </Text>
          </View>
        </View>
        
        <View style={styles.priceContainer}>
          <Text style={styles.price}>₹{worker.pricePerHour}/hr</Text>
          <View style={[styles.statusBadge, worker.isAvailable ? styles.available : styles.busy]}>
            <Clock size={12} color={worker.isAvailable ? Colors.success : Colors.warning} strokeWidth={2} />
            <Text style={[styles.statusText, worker.isAvailable ? styles.availableText : styles.busyText]}>
              {worker.isAvailable ? 'Available' : 'Busy'}
            </Text>
          </View>
        </View>
      </View>
      
      <View style={styles.footer}>
        <Text style={styles.experience}>{worker.experience} years experience</Text>
        <Text style={styles.services}>
          {worker.services.slice(0, 2).join(', ')}
          {worker.services.length > 2 && ` +${worker.services.length - 2} more`}
        </Text>
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: Colors.white,
    borderRadius: 16,
    padding: 16,
    marginBottom: 12,
    shadowColor: Colors.black,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
    borderWidth: 1,
    borderColor: Colors.gray100,
  },
  header: {
    flexDirection: 'row',
    marginBottom: 12,
  },
  avatarContainer: {
    position: 'relative',
    marginRight: 12,
  },
  avatar: {
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: Colors.gray200,
  },
  verifiedBadge: {
    position: 'absolute',
    bottom: -2,
    right: -2,
    width: 20,
    height: 20,
    borderRadius: 10,
    backgroundColor: Colors.success,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2,
    borderColor: Colors.white,
  },
  info: {
    flex: 1,
    justifyContent: 'space-between',
  },
  name: {
    fontSize: 16,
    fontFamily: 'Poppins-SemiBold',
    color: Colors.textPrimary,
    marginBottom: 4,
  },
  ratingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 4,
  },
  rating: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: Colors.textPrimary,
    marginLeft: 4,
  },
  jobCount: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: Colors.textSecondary,
    marginLeft: 4,
  },
  locationContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  location: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: Colors.textSecondary,
    marginLeft: 4,
    flex: 1,
  },
  priceContainer: {
    alignItems: 'flex-end',
  },
  price: {
    fontSize: 16,
    fontFamily: 'Inter-Bold',
    color: Colors.primary,
    marginBottom: 8,
  },
  statusBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
  },
  available: {
    backgroundColor: Colors.success + '20',
  },
  busy: {
    backgroundColor: Colors.warning + '20',
  },
  statusText: {
    fontSize: 11,
    fontFamily: 'Inter-Medium',
    marginLeft: 4,
  },
  availableText: {
    color: Colors.success,
  },
  busyText: {
    color: Colors.warning,
  },
  footer: {
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: Colors.gray100,
  },
  experience: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: Colors.textSecondary,
    marginBottom: 4,
  },
  services: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: Colors.textTertiary,
  },
});