import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, Image, TouchableOpacity } from 'react-native';
import { router } from 'expo-router';
import { Colors } from '@/constants/Colors';
import Button from '@/components/Button';
import { LinearGradient } from 'expo-linear-gradient';
import { MapPin, Clock, Shield, Star } from 'lucide-react-native';

export default function WelcomeScreen() {
  const [currentSlide, setCurrentSlide] = useState(0);

  const slides = [
    {
      title: 'Find Skilled Workers',
      subtitle: 'Connect with verified electricians, plumbers, carpenters & more in your area',
      icon: MapPin
    },
    {
      title: 'Quick & Reliable',
      subtitle: 'Get your work done quickly by experienced professionals you can trust',
      icon: Clock
    },
    {
      title: 'Verified Professionals',
      subtitle: 'All workers are background verified with ratings from real customers',
      icon: Shield
    }
  ];

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % slides.length);
    }, 3000);
    return () => clearInterval(timer);
  }, []);

  const handleGetStarted = () => {
    router.push('/auth');
  };

  const CurrentIcon = slides[currentSlide].icon;

  return (
    <LinearGradient
      colors={[Colors.primary, Colors.primaryDark]}
      style={styles.container}
    >
      <View style={styles.header}>
        <Image
          source={{ uri: 'https://images.pexels.com/photos/1267320/pexels-photo-1267320.jpeg?auto=compress&cs=tinysrgb&w=300&h=200&fit=crop' }}
          style={styles.heroImage}
        />
        <View style={styles.overlay} />
        <View style={styles.logoContainer}>
          <View style={styles.logo}>
            <Text style={styles.logoText}>WorkEase</Text>
          </View>
          <Text style={styles.tagline}>Skilled Workers On-Demand</Text>
        </View>
      </View>

      <View style={styles.content}>
        <View style={styles.slideContainer}>
          <View style={styles.iconContainer}>
            <CurrentIcon size={40} color={Colors.white} strokeWidth={2} />
          </View>
          <Text style={styles.slideTitle}>{slides[currentSlide].title}</Text>
          <Text style={styles.slideSubtitle}>{slides[currentSlide].subtitle}</Text>
        </View>

        <View style={styles.indicators}>
          {slides.map((_, index) => (
            <View
              key={index}
              style={[
                styles.indicator,
                index === currentSlide && styles.activeIndicator
              ]}
            />
          ))}
        </View>

        <View style={styles.statsContainer}>
          <View style={styles.statItem}>
            <Text style={styles.statNumber}>1000+</Text>
            <Text style={styles.statLabel}>Workers</Text>
          </View>
          <View style={styles.statDivider} />
          <View style={styles.statItem}>
            <Text style={styles.statNumber}>5000+</Text>
            <Text style={styles.statLabel}>Jobs Done</Text>
          </View>
          <View style={styles.statDivider} />
          <View style={styles.statItem}>
            <View style={styles.ratingContainer}>
              <Star size={16} color={Colors.accent} fill={Colors.accent} strokeWidth={0} />
              <Text style={styles.statNumber}>4.8</Text>
            </View>
            <Text style={styles.statLabel}>Rating</Text>
          </View>
        </View>

        <Button
          title="Get Started"
          onPress={handleGetStarted}
          variant="secondary"
          size="large"
          style={styles.getStartedButton}
        />

        <TouchableOpacity onPress={() => router.push('/auth')}>
          <Text style={styles.loginText}>Already have an account? Login</Text>
        </TouchableOpacity>
      </View>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    height: '45%',
    position: 'relative',
  },
  heroImage: {
    width: '100%',
    height: '100%',
    resizeMode: 'cover',
  },
  overlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: Colors.primary + '80',
  },
  logoContainer: {
    position: 'absolute',
    top: '50%',
    left: 0,
    right: 0,
    alignItems: 'center',
    transform: [{ translateY: -40 }],
  },
  logo: {
    backgroundColor: Colors.white,
    paddingHorizontal: 24,
    paddingVertical: 12,
    borderRadius: 25,
    marginBottom: 12,
  },
  logoText: {
    fontSize: 28,
    fontFamily: 'Poppins-Bold',
    color: Colors.primary,
  },
  tagline: {
    fontSize: 16,
    fontFamily: 'Inter-Medium',
    color: Colors.white,
    textAlign: 'center',
  },
  content: {
    flex: 1,
    paddingHorizontal: 24,
    paddingTop: 40,
    alignItems: 'center',
  },
  slideContainer: {
    alignItems: 'center',
    marginBottom: 40,
  },
  iconContainer: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: Colors.white + '20',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 20,
  },
  slideTitle: {
    fontSize: 24,
    fontFamily: 'Poppins-SemiBold',
    color: Colors.white,
    textAlign: 'center',
    marginBottom: 12,
  },
  slideSubtitle: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: Colors.white + 'E0',
    textAlign: 'center',
    lineHeight: 24,
  },
  indicators: {
    flexDirection: 'row',
    marginBottom: 40,
  },
  indicator: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: Colors.white + '40',
    marginHorizontal: 4,
  },
  activeIndicator: {
    backgroundColor: Colors.white,
    width: 20,
  },
  statsContainer: {
    flexDirection: 'row',
    backgroundColor: Colors.white + '15',
    borderRadius: 16,
    paddingVertical: 20,
    paddingHorizontal: 24,
    marginBottom: 40,
    alignItems: 'center',
  },
  statItem: {
    flex: 1,
    alignItems: 'center',
  },
  statDivider: {
    width: 1,
    height: 30,
    backgroundColor: Colors.white + '30',
  },
  ratingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  statNumber: {
    fontSize: 20,
    fontFamily: 'Poppins-Bold',
    color: Colors.white,
    marginBottom: 4,
  },
  statLabel: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: Colors.white + 'C0',
  },
  getStartedButton: {
    width: '100%',
    marginBottom: 20,
  },
  loginText: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: Colors.white + 'E0',
    textAlign: 'center',
  },
});