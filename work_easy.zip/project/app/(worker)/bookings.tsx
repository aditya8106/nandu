import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Colors } from '@/constants/Colors';
import { Clock, MapPin, DollarSign, User, Phone, MessageCircle, Navigation } from 'lucide-react-native';

const JOB_TABS = ['Active', 'Completed', 'Cancelled'];

const MOCK_WORKER_JOBS = [
  {
    id: '1',
    service: 'Electrical Repair',
    customer: 'Priya Sharma',
    status: 'ongoing',
    scheduledTime: '2024-01-15T14:00:00Z',
    location: 'Flat 301, Sai Residency, Kakinada',
    price: 350,
    description: 'Fix ceiling fan and power socket',
    customerPhone: '+91 9876543210'
  },
  {
    id: '2',
    service: 'Wiring Installation',
    customer: 'Ravi Kumar',
    status: 'accepted',
    scheduledTime: '2024-01-15T16:30:00Z',
    location: 'House No. 45, Gandhi Nagar',
    price: 800,
    description: 'Complete wiring for new room',
    customerPhone: '+91 9876543211'
  },
  {
    id: '3',
    service: 'Switch Replacement',
    customer: 'Suresh Babu',
    status: 'completed',
    scheduledTime: '2024-01-10T10:00:00Z',
    location: 'Office 12, Business Park',
    price: 200,
    description: 'Replace 3 electrical switches',
    customerPhone: '+91 9876543212',
    rating: 5,
    review: 'Excellent work! Very professional and quick.'
  }
];

export default function WorkerBookingsScreen() {
  const [activeTab, setActiveTab] = useState('Active');

  const getFilteredJobs = () => {
    switch (activeTab) {
      case 'Active':
        return MOCK_WORKER_JOBS.filter(j => ['accepted', 'ongoing'].includes(j.status));
      case 'Completed':
        return MOCK_WORKER_JOBS.filter(j => j.status === 'completed');
      case 'Cancelled':
        return MOCK_WORKER_JOBS.filter(j => j.status === 'cancelled');
      default:
        return MOCK_WORKER_JOBS;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'accepted':
        return Colors.info;
      case 'ongoing':
        return Colors.warning;
      case 'completed':
        return Colors.success;
      case 'cancelled':
        return Colors.error;
      default:
        return Colors.textSecondary;
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'accepted':
        return 'Accepted';
      case 'ongoing':
        return 'In Progress';
      case 'completed':
        return 'Completed';
      case 'cancelled':
        return 'Cancelled';
      default:
        return status;
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-IN', {
      day: 'numeric',
      month: 'short',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const handleStartJob = (jobId: string) => {
    console.log('Start job:', jobId);
  };

  const handleCompleteJob = (jobId: string) => {
    console.log('Complete job:', jobId);
  };

  const handleNavigate = (location: string) => {
    console.log('Navigate to:', location);
  };

  const renderJobCard = (job: any) => (
    <View key={job.id} style={styles.jobCard}>
      <View style={styles.jobHeader}>
        <View style={styles.serviceInfo}>
          <Text style={styles.serviceName}>{job.service}</Text>
          <View style={styles.customerInfo}>
            <User size={14} color={Colors.textSecondary} strokeWidth={2} />
            <Text style={styles.customerName}>{job.customer}</Text>
          </View>
        </View>
        <View style={[styles.statusBadge, { backgroundColor: getStatusColor(job.status) + '20' }]}>
          <Text style={[styles.statusText, { color: getStatusColor(job.status) }]}>
            {getStatusText(job.status)}
          </Text>
        </View>
      </View>

      <Text style={styles.description}>{job.description}</Text>

      <View style={styles.jobDetails}>
        <View style={styles.detailRow}>
          <Clock size={16} color={Colors.textSecondary} strokeWidth={2} />
          <Text style={styles.detailText}>{formatDate(job.scheduledTime)}</Text>
        </View>
        <View style={styles.detailRow}>
          <MapPin size={16} color={Colors.textSecondary} strokeWidth={2} />
          <Text style={styles.detailText} numberOfLines={2}>{job.location}</Text>
          {job.status === 'accepted' && (
            <TouchableOpacity 
              style={styles.navigateButton}
              onPress={() => handleNavigate(job.location)}
            >
              <Navigation size={14} color={Colors.primary} strokeWidth={2} />
            </TouchableOpacity>
          )}
        </View>
        <View style={styles.detailRow}>
          <DollarSign size={16} color={Colors.primary} strokeWidth={2} />
          <Text style={styles.price}>₹{job.price}</Text>
        </View>
      </View>

      {job.rating && job.review && (
        <View style={styles.reviewSection}>
          <View style={styles.ratingRow}>
            <Text style={styles.ratingLabel}>Customer Rating:</Text>
            <Text style={styles.ratingValue}>⭐ {job.rating}/5</Text>
          </View>
          <Text style={styles.reviewText}>"{job.review}"</Text>
        </View>
      )}

      <View style={styles.jobActions}>
        <View style={styles.contactButtons}>
          <TouchableOpacity style={styles.contactButton}>
            <Phone size={16} color={Colors.success} strokeWidth={2} />
          </TouchableOpacity>
          <TouchableOpacity style={styles.contactButton}>
            <MessageCircle size={16} color={Colors.info} strokeWidth={2} />
          </TouchableOpacity>
        </View>

        {job.status === 'accepted' && (
          <TouchableOpacity 
            style={styles.startButton}
            onPress={() => handleStartJob(job.id)}
          >
            <Text style={styles.startText}>Start Job</Text>
          </TouchableOpacity>
        )}

        {job.status === 'ongoing' && (
          <TouchableOpacity 
            style={styles.completeButton}
            onPress={() => handleCompleteJob(job.id)}
          >
            <Text style={styles.completeText}>Complete</Text>
          </TouchableOpacity>
        )}
      </View>
    </View>
  );

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>My Jobs</Text>
      </View>

      <View style={styles.tabContainer}>
        {JOB_TABS.map((tab) => (
          <TouchableOpacity
            key={tab}
            style={[styles.tab, activeTab === tab && styles.activeTab]}
            onPress={() => setActiveTab(tab)}
          >
            <Text style={[styles.tabText, activeTab === tab && styles.activeTabText]}>
              {tab}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        {getFilteredJobs().length > 0 ? (
          getFilteredJobs().map(renderJobCard)
        ) : (
          <View style={styles.emptyState}>
            <Text style={styles.emptyTitle}>No jobs found</Text>
            <Text style={styles.emptyText}>
              {activeTab === 'Active' 
                ? 'You have no active jobs' 
                : `You have no ${activeTab.toLowerCase()} jobs`}
            </Text>
          </View>
        )}
        
        <View style={styles.bottomPadding} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.backgroundSecondary,
  },
  header: {
    backgroundColor: Colors.white,
    paddingHorizontal: 24,
    paddingVertical: 20,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  title: {
    fontSize: 24,
    fontFamily: 'Poppins-SemiBold',
    color: Colors.textPrimary,
  },
  tabContainer: {
    flexDirection: 'row',
    backgroundColor: Colors.white,
    paddingHorizontal: 24,
    paddingBottom: 8,
  },
  tab: {
    flex: 1,
    paddingVertical: 12,
    alignItems: 'center',
    borderBottomWidth: 2,
    borderBottomColor: 'transparent',
  },
  activeTab: {
    borderBottomColor: Colors.primary,
  },
  tabText: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: Colors.textSecondary,
  },
  activeTabText: {
    color: Colors.primary,
  },
  content: {
    flex: 1,
    paddingHorizontal: 24,
    paddingTop: 16,
  },
  jobCard: {
    backgroundColor: Colors.white,
    borderRadius: 16,
    padding: 20,
    marginBottom: 16,
    shadowColor: Colors.black,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },
  jobHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 12,
  },
  serviceInfo: {
    flex: 1,
  },
  serviceName: {
    fontSize: 18,
    fontFamily: 'Poppins-SemiBold',
    color: Colors.textPrimary,
    marginBottom: 6,
  },
  customerInfo: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  customerName: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: Colors.textSecondary,
    marginLeft: 6,
  },
  statusBadge: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 12,
  },
  statusText: {
    fontSize: 12,
    fontFamily: 'Inter-SemiBold',
  },
  description: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: Colors.textSecondary,
    marginBottom: 16,
    lineHeight: 20,
  },
  jobDetails: {
    marginBottom: 16,
  },
  detailRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  detailText: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: Colors.textSecondary,
    marginLeft: 8,
    flex: 1,
  },
  navigateButton: {
    width: 28,
    height: 28,
    borderRadius: 14,
    backgroundColor: Colors.primary + '20',
    alignItems: 'center',
    justifyContent: 'center',
    marginLeft: 8,
  },
  price: {
    fontSize: 16,
    fontFamily: 'Inter-Bold',
    color: Colors.primary,
    marginLeft: 8,
  },
  reviewSection: {
    backgroundColor: Colors.gray50,
    borderRadius: 12,
    padding: 12,
    marginBottom: 16,
  },
  ratingRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 6,
  },
  ratingLabel: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: Colors.textSecondary,
  },
  ratingValue: {
    fontSize: 12,
    fontFamily: 'Inter-SemiBold',
    color: Colors.textPrimary,
  },
  reviewText: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: Colors.textSecondary,
    fontStyle: 'italic',
  },
  jobActions: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingTop: 16,
    borderTopWidth: 1,
    borderTopColor: Colors.border,
  },
  contactButtons: {
    flexDirection: 'row',
    gap: 8,
  },
  contactButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: Colors.gray50,
    alignItems: 'center',
    justifyContent: 'center',
  },
  startButton: {
    paddingHorizontal: 24,
    paddingVertical: 10,
    borderRadius: 20,
    backgroundColor: Colors.info,
  },
  startText: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: Colors.white,
  },
  completeButton: {
    paddingHorizontal: 24,
    paddingVertical: 10,
    borderRadius: 20,
    backgroundColor: Colors.success,
  },
  completeText: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: Colors.white,
  },
  emptyState: {
    alignItems: 'center',
    paddingVertical: 60,
  },
  emptyTitle: {
    fontSize: 18,
    fontFamily: 'Poppins-SemiBold',
    color: Colors.textPrimary,
    marginBottom: 8,
  },
  emptyText: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: Colors.textSecondary,
    textAlign: 'center',
  },
  bottomPadding: {
    height: 100,
  },
});