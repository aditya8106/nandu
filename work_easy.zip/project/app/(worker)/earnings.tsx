import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Colors } from '@/constants/Colors';
import { DollarSign, TrendingUp, Calendar, Download, Eye } from 'lucide-react-native';

const TIME_PERIODS = ['Today', 'This Week', 'This Month', 'All Time'];

const EARNINGS_DATA = {
  today: { total: 1250, jobs: 3, hours: 6.5 },
  week: { total: 8400, jobs: 18, hours: 42 },
  month: { total: 32500, jobs: 67, hours: 156 },
  allTime: { total: 125000, jobs: 234, hours: 567 }
};

const RECENT_PAYMENTS = [
  {
    id: '1',
    customer: 'Priya Sharma',
    service: 'Electrical Repair',
    amount: 350,
    date: '2024-01-15',
    status: 'paid'
  },
  {
    id: '2',
    customer: 'Ravi Kumar',
    service: 'Wiring Installation',
    amount: 800,
    date: '2024-01-15',
    status: 'paid'
  },
  {
    id: '3',
    customer: 'Suresh Babu',
    service: 'Switch Replacement',
    amount: 200,
    date: '2024-01-14',
    status: 'pending'
  },
  {
    id: '4',
    customer: 'Lakshmi Devi',
    service: 'Fan Installation',
    amount: 450,
    date: '2024-01-14',
    status: 'paid'
  }
];

export default function EarningsScreen() {
  const [selectedPeriod, setSelectedPeriod] = useState('This Month');

  const getCurrentData = () => {
    switch (selectedPeriod) {
      case 'Today':
        return EARNINGS_DATA.today;
      case 'This Week':
        return EARNINGS_DATA.week;
      case 'This Month':
        return EARNINGS_DATA.month;
      case 'All Time':
        return EARNINGS_DATA.allTime;
      default:
        return EARNINGS_DATA.month;
    }
  };

  const currentData = getCurrentData();

  const formatCurrency = (amount: number) => {
    return `₹${amount.toLocaleString('en-IN')}`;
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-IN', {
      day: 'numeric',
      month: 'short'
    });
  };

  const getStatusColor = (status: string) => {
    return status === 'paid' ? Colors.success : Colors.warning;
  };

  const renderPaymentItem = (payment: any) => (
    <View key={payment.id} style={styles.paymentItem}>
      <View style={styles.paymentInfo}>
        <Text style={styles.customerName}>{payment.customer}</Text>
        <Text style={styles.serviceName}>{payment.service}</Text>
        <Text style={styles.paymentDate}>{formatDate(payment.date)}</Text>
      </View>
      <View style={styles.paymentAmount}>
        <Text style={styles.amount}>{formatCurrency(payment.amount)}</Text>
        <View style={[styles.statusBadge, { backgroundColor: getStatusColor(payment.status) + '20' }]}>
          <Text style={[styles.statusText, { color: getStatusColor(payment.status) }]}>
            {payment.status}
          </Text>
        </View>
      </View>
    </View>
  );

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Earnings</Text>
        <TouchableOpacity style={styles.downloadButton}>
          <Download size={20} color={Colors.primary} strokeWidth={2} />
        </TouchableOpacity>
      </View>

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        {/* Time Period Selector */}
        <View style={styles.periodSelector}>
          <ScrollView horizontal showsHorizontalScrollIndicator={false}>
            <View style={styles.periodTabs}>
              {TIME_PERIODS.map((period) => (
                <TouchableOpacity
                  key={period}
                  style={[
                    styles.periodTab,
                    selectedPeriod === period && styles.activePeriodTab
                  ]}
                  onPress={() => setSelectedPeriod(period)}
                >
                  <Text style={[
                    styles.periodTabText,
                    selectedPeriod === period && styles.activePeriodTabText
                  ]}>
                    {period}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
          </ScrollView>
        </View>

        {/* Earnings Summary */}
        <View style={styles.summaryCard}>
          <View style={styles.summaryHeader}>
            <View style={styles.summaryIconContainer}>
              <DollarSign size={24} color={Colors.primary} strokeWidth={2} />
            </View>
            <View style={styles.summaryTitle}>
              <Text style={styles.summaryLabel}>Total Earnings</Text>
              <Text style={styles.summaryPeriod}>{selectedPeriod}</Text>
            </View>
            <View style={styles.trendContainer}>
              <TrendingUp size={16} color={Colors.success} strokeWidth={2} />
              <Text style={styles.trendText}>+12%</Text>
            </View>
          </View>
          <Text style={styles.totalAmount}>{formatCurrency(currentData.total)}</Text>
          
          <View style={styles.summaryStats}>
            <View style={styles.statItem}>
              <Text style={styles.statValue}>{currentData.jobs}</Text>
              <Text style={styles.statLabel}>Jobs Completed</Text>
            </View>
            <View style={styles.statDivider} />
            <View style={styles.statItem}>
              <Text style={styles.statValue}>{currentData.hours}</Text>
              <Text style={styles.statLabel}>Hours Worked</Text>
            </View>
            <View style={styles.statDivider} />
            <View style={styles.statItem}>
              <Text style={styles.statValue}>
                {formatCurrency(Math.round(currentData.total / currentData.hours))}
              </Text>
              <Text style={styles.statLabel}>Per Hour</Text>
            </View>
          </View>
        </View>

        {/* Quick Actions */}
        <View style={styles.actionsContainer}>
          <TouchableOpacity style={styles.actionCard}>
            <View style={styles.actionIcon}>
              <Eye size={20} color={Colors.info} strokeWidth={2} />
            </View>
            <Text style={styles.actionText}>View Analytics</Text>
          </TouchableOpacity>
          
          <TouchableOpacity style={styles.actionCard}>
            <View style={styles.actionIcon}>
              <Calendar size={20} color={Colors.secondary} strokeWidth={2} />
            </View>
            <Text style={styles.actionText}>Set Goals</Text>
          </TouchableOpacity>
        </View>

        {/* Recent Payments */}
        <View style={styles.paymentsSection}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Recent Payments</Text>
            <TouchableOpacity>
              <Text style={styles.viewAllText}>View All</Text>
            </TouchableOpacity>
          </View>
          
          <View style={styles.paymentsList}>
            {RECENT_PAYMENTS.map(renderPaymentItem)}
          </View>
        </View>

        {/* Payout Info */}
        <View style={styles.payoutInfo}>
          <Text style={styles.payoutTitle}>Next Payout</Text>
          <Text style={styles.payoutText}>
            Your earnings will be transferred to your bank account on every Friday
          </Text>
          <View style={styles.payoutAmount}>
            <Text style={styles.payoutLabel}>Pending Amount:</Text>
            <Text style={styles.payoutValue}>₹2,850</Text>
          </View>
        </View>

        <View style={styles.bottomPadding} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.backgroundSecondary,
  },
  header: {
    backgroundColor: Colors.white,
    paddingHorizontal: 24,
    paddingVertical: 20,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  title: {
    fontSize: 24,
    fontFamily: 'Poppins-SemiBold',
    color: Colors.textPrimary,
  },
  downloadButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: Colors.gray50,
    alignItems: 'center',
    justifyContent: 'center',
  },
  content: {
    flex: 1,
  },
  periodSelector: {
    backgroundColor: Colors.white,
    paddingVertical: 16,
    marginBottom: 16,
  },
  periodTabs: {
    flexDirection: 'row',
    paddingHorizontal: 24,
    gap: 12,
  },
  periodTab: {
    paddingHorizontal: 20,
    paddingVertical: 8,
    borderRadius: 20,
    backgroundColor: Colors.gray100,
  },
  activePeriodTab: {
    backgroundColor: Colors.primary,
  },
  periodTabText: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: Colors.textSecondary,
  },
  activePeriodTabText: {
    color: Colors.white,
  },
  summaryCard: {
    backgroundColor: Colors.white,
    marginHorizontal: 24,
    borderRadius: 20,
    padding: 24,
    marginBottom: 16,
    shadowColor: Colors.black,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 12,
    elevation: 6,
  },
  summaryHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  summaryIconContainer: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: Colors.primary + '20',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  summaryTitle: {
    flex: 1,
  },
  summaryLabel: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: Colors.textPrimary,
  },
  summaryPeriod: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: Colors.textSecondary,
  },
  trendContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.success + '20',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
  },
  trendText: {
    fontSize: 12,
    fontFamily: 'Inter-SemiBold',
    color: Colors.success,
    marginLeft: 4,
  },
  totalAmount: {
    fontSize: 36,
    fontFamily: 'Poppins-Bold',
    color: Colors.textPrimary,
    marginBottom: 20,
  },
  summaryStats: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  statItem: {
    flex: 1,
    alignItems: 'center',
  },
  statDivider: {
    width: 1,
    height: 40,
    backgroundColor: Colors.border,
  },
  statValue: {
    fontSize: 18,
    fontFamily: 'Poppins-SemiBold',
    color: Colors.textPrimary,
    marginBottom: 4,
  },
  statLabel: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: Colors.textSecondary,
    textAlign: 'center',
  },
  actionsContainer: {
    flexDirection: 'row',
    paddingHorizontal: 24,
    marginBottom: 16,
    gap: 12,
  },
  actionCard: {
    flex: 1,
    backgroundColor: Colors.white,
    borderRadius: 16,
    padding: 20,
    alignItems: 'center',
  },
  actionIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: Colors.gray50,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 12,
  },
  actionText: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: Colors.textPrimary,
    textAlign: 'center',
  },
  paymentsSection: {
    backgroundColor: Colors.white,
    marginHorizontal: 24,
    borderRadius: 16,
    padding: 20,
    marginBottom: 16,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  sectionTitle: {
    fontSize: 18,
    fontFamily: 'Poppins-SemiBold',
    color: Colors.textPrimary,
  },
  viewAllText: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: Colors.primary,
  },
  paymentsList: {
    gap: 12,
  },
  paymentItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  paymentInfo: {
    flex: 1,
  },
  customerName: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: Colors.textPrimary,
    marginBottom: 2,
  },
  serviceName: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: Colors.textSecondary,
    marginBottom: 2,
  },
  paymentDate: {
    fontSize: 11,
    fontFamily: 'Inter-Regular',
    color: Colors.textTertiary,
  },
  paymentAmount: {
    alignItems: 'flex-end',
  },
  amount: {
    fontSize: 16,
    fontFamily: 'Inter-Bold',
    color: Colors.textPrimary,
    marginBottom: 4,
  },
  statusBadge: {
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 8,
  },
  statusText: {
    fontSize: 10,
    fontFamily: 'Inter-SemiBold',
    textTransform: 'uppercase',
  },
  payoutInfo: {
    backgroundColor: Colors.info + '10',
    marginHorizontal: 24,
    borderRadius: 16,
    padding: 20,
    borderLeftWidth: 4,
    borderLeftColor: Colors.info,
  },
  payoutTitle: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: Colors.textPrimary,
    marginBottom: 8,
  },
  payoutText: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: Colors.textSecondary,
    lineHeight: 20,
    marginBottom: 12,
  },
  payoutAmount: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  payoutLabel: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: Colors.textSecondary,
  },
  payoutValue: {
    fontSize: 16,
    fontFamily: 'Inter-Bold',
    color: Colors.info,
  },
  bottomPadding: {
    height: 100,
  },
});