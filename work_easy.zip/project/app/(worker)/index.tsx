import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Switch } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Colors } from '@/constants/Colors';
import { MapPin, Clock, DollarSign, User, Phone, MessageCircle } from 'lucide-react-native';

const MOCK_JOBS = [
  {
    id: '1',
    service: 'Electrical Repair',
    customer: 'Priya Sharma',
    location: 'Flat 301, Sai Residency, Kakinada',
    scheduledTime: '2024-01-15T14:00:00Z',
    price: 350,
    description: 'Need to fix ceiling fan and power socket',
    distance: 2.5,
    urgency: 'normal'
  },
  {
    id: '2',
    service: 'Wiring Installation',
    customer: 'Ravi Kumar',
    location: 'House No. 45, Gandhi Nagar',
    scheduledTime: '2024-01-15T16:30:00Z',
    price: 800,
    description: 'Complete wiring for new room',
    distance: 1.8,
    urgency: 'urgent'
  },
  {
    id: '3',
    service: 'Switch Replacement',
    customer: 'Suresh Babu',
    location: 'Office 12, Business Park',
    scheduledTime: '2024-01-16T10:00:00Z',
    price: 200,
    description: 'Replace 3 electrical switches',
    distance: 3.2,
    urgency: 'normal'
  }
];

export default function WorkerJobsScreen() {
  const [isOnline, setIsOnline] = useState(true);

  const formatTime = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleTimeString('en-IN', {
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    const today = new Date();
    const tomorrow = new Date(today);
    tomorrow.setDate(today.getDate() + 1);

    if (date.toDateString() === today.toDateString()) {
      return 'Today';
    } else if (date.toDateString() === tomorrow.toDateString()) {
      return 'Tomorrow';
    } else {
      return date.toLocaleDateString('en-IN', { day: 'numeric', month: 'short' });
    }
  };

  const getUrgencyColor = (urgency: string) => {
    return urgency === 'urgent' ? Colors.error : Colors.primary;
  };

  const handleAcceptJob = (jobId: string) => {
    console.log('Accept job:', jobId);
  };

  const handleDeclineJob = (jobId: string) => {
    console.log('Decline job:', jobId);
  };

  const renderJobCard = (job: any) => (
    <View key={job.id} style={styles.jobCard}>
      <View style={styles.jobHeader}>
        <View style={styles.serviceInfo}>
          <Text style={styles.serviceName}>{job.service}</Text>
          <View style={styles.customerInfo}>
            <User size={14} color={Colors.textSecondary} strokeWidth={2} />
            <Text style={styles.customerName}>{job.customer}</Text>
          </View>
        </View>
        <View style={[styles.urgencyBadge, { backgroundColor: getUrgencyColor(job.urgency) + '20' }]}>
          <Text style={[styles.urgencyText, { color: getUrgencyColor(job.urgency) }]}>
            {job.urgency === 'urgent' ? 'URGENT' : 'NORMAL'}
          </Text>
        </View>
      </View>

      <Text style={styles.description}>{job.description}</Text>

      <View style={styles.jobDetails}>
        <View style={styles.detailRow}>
          <Clock size={16} color={Colors.textSecondary} strokeWidth={2} />
          <Text style={styles.detailText}>
            {formatDate(job.scheduledTime)} at {formatTime(job.scheduledTime)}
          </Text>
        </View>
        <View style={styles.detailRow}>
          <MapPin size={16} color={Colors.textSecondary} strokeWidth={2} />
          <Text style={styles.detailText}>{job.location}</Text>
          <Text style={styles.distance}>({job.distance} km away)</Text>
        </View>
        <View style={styles.detailRow}>
          <DollarSign size={16} color={Colors.primary} strokeWidth={2} />
          <Text style={styles.price}>₹{job.price}</Text>
        </View>
      </View>

      <View style={styles.jobActions}>
        <TouchableOpacity 
          style={styles.declineButton}
          onPress={() => handleDeclineJob(job.id)}
        >
          <Text style={styles.declineText}>Decline</Text>
        </TouchableOpacity>
        
        <View style={styles.contactButtons}>
          <TouchableOpacity style={styles.contactButton}>
            <Phone size={16} color={Colors.success} strokeWidth={2} />
          </TouchableOpacity>
          <TouchableOpacity style={styles.contactButton}>
            <MessageCircle size={16} color={Colors.info} strokeWidth={2} />
          </TouchableOpacity>
        </View>

        <TouchableOpacity 
          style={styles.acceptButton}
          onPress={() => handleAcceptJob(job.id)}
        >
          <Text style={styles.acceptText}>Accept</Text>
        </TouchableOpacity>
      </View>
    </View>
  );

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <View style={styles.headerTop}>
          <Text style={styles.title}>Available Jobs</Text>
          <View style={styles.onlineToggle}>
            <Text style={[styles.onlineText, !isOnline && styles.offlineText]}>
              {isOnline ? 'Online' : 'Offline'}
            </Text>
            <Switch
              value={isOnline}
              onValueChange={setIsOnline}
              trackColor={{ false: Colors.gray300, true: Colors.success + '40' }}
              thumbColor={isOnline ? Colors.success : Colors.gray400}
            />
          </View>
        </View>
        
        {isOnline && (
          <View style={styles.statusCard}>
            <Text style={styles.statusText}>You're online and ready to accept jobs</Text>
          </View>
        )}
      </View>

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        {isOnline ? (
          MOCK_JOBS.length > 0 ? (
            MOCK_JOBS.map(renderJobCard)
          ) : (
            <View style={styles.emptyState}>
              <Text style={styles.emptyTitle}>No jobs available</Text>
              <Text style={styles.emptyText}>
                New job requests will appear here when customers book your services
              </Text>
            </View>
          )
        ) : (
          <View style={styles.offlineState}>
            <Text style={styles.offlineTitle}>You're offline</Text>
            <Text style={styles.offlineText}>
              Turn on availability to start receiving job requests
            </Text>
          </View>
        )}
        
        <View style={styles.bottomPadding} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.backgroundSecondary,
  },
  header: {
    backgroundColor: Colors.white,
    paddingHorizontal: 24,
    paddingVertical: 20,
  },
  headerTop: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  title: {
    fontSize: 24,
    fontFamily: 'Poppins-SemiBold',
    color: Colors.textPrimary,
  },
  onlineToggle: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  onlineText: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: Colors.success,
  },
  offlineText: {
    color: Colors.textSecondary,
  },
  statusCard: {
    backgroundColor: Colors.success + '10',
    borderRadius: 12,
    padding: 12,
    borderLeftWidth: 4,
    borderLeftColor: Colors.success,
  },
  statusText: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: Colors.success,
  },
  content: {
    flex: 1,
    paddingHorizontal: 24,
    paddingTop: 16,
  },
  jobCard: {
    backgroundColor: Colors.white,
    borderRadius: 16,
    padding: 20,
    marginBottom: 16,
    shadowColor: Colors.black,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },
  jobHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 12,
  },
  serviceInfo: {
    flex: 1,
  },
  serviceName: {
    fontSize: 18,
    fontFamily: 'Poppins-SemiBold',
    color: Colors.textPrimary,
    marginBottom: 6,
  },
  customerInfo: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  customerName: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: Colors.textSecondary,
    marginLeft: 6,
  },
  urgencyBadge: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
  },
  urgencyText: {
    fontSize: 10,
    fontFamily: 'Inter-Bold',
    letterSpacing: 0.5,
  },
  description: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: Colors.textSecondary,
    marginBottom: 16,
    lineHeight: 20,
  },
  jobDetails: {
    marginBottom: 20,
  },
  detailRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  detailText: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: Colors.textSecondary,
    marginLeft: 8,
    flex: 1,
  },
  distance: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: Colors.textTertiary,
  },
  price: {
    fontSize: 16,
    fontFamily: 'Inter-Bold',
    color: Colors.primary,
    marginLeft: 8,
  },
  jobActions: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingTop: 16,
    borderTopWidth: 1,
    borderTopColor: Colors.border,
  },
  declineButton: {
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderRadius: 20,
    backgroundColor: Colors.gray100,
  },
  declineText: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: Colors.textSecondary,
  },
  contactButtons: {
    flexDirection: 'row',
    gap: 8,
  },
  contactButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: Colors.gray50,
    alignItems: 'center',
    justifyContent: 'center',
  },
  acceptButton: {
    paddingHorizontal: 24,
    paddingVertical: 10,
    borderRadius: 20,
    backgroundColor: Colors.primary,
  },
  acceptText: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: Colors.white,
  },
  emptyState: {
    alignItems: 'center',
    paddingVertical: 60,
  },
  emptyTitle: {
    fontSize: 18,
    fontFamily: 'Poppins-SemiBold',
    color: Colors.textPrimary,
    marginBottom: 8,
  },
  emptyText: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: Colors.textSecondary,
    textAlign: 'center',
    paddingHorizontal: 40,
  },
  offlineState: {
    alignItems: 'center',
    paddingVertical: 60,
  },
  offlineTitle: {
    fontSize: 18,
    fontFamily: 'Poppins-SemiBold',
    color: Colors.textPrimary,
    marginBottom: 8,
  },
  offlineText: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: Colors.textSecondary,
    textAlign: 'center',
    paddingHorizontal: 40,
  },
  bottomPadding: {
    height: 100,
  },
});