import React, { useState } from 'react';
import { View, Text, StyleSheet, TextInput, Alert, KeyboardAvoidingView, Platform, ScrollView } from 'react-native';
import { router } from 'expo-router';
import { Colors } from '@/constants/Colors';
import Button from '@/components/Button';
import { Phone, User, Briefcase, Users } from 'lucide-react-native';
import { TouchableOpacity } from 'react-native';

export default function AuthScreen() {
  const [step, setStep] = useState<'phone' | 'otp' | 'profile'>('phone');
  const [phone, setPhone] = useState('');
  const [otp, setOtp] = useState('');
  const [name, setName] = useState('');
  const [userType, setUserType] = useState<'customer' | 'worker' | null>(null);
  const [loading, setLoading] = useState(false);

  const handleSendOTP = async () => {
    if (phone.length !== 10) {
      Alert.alert('Error', 'Please enter a valid 10-digit phone number');
      return;
    }

    setLoading(true);
    // Simulate API call
    setTimeout(() => {
      setLoading(false);
      setStep('otp');
      Alert.alert('OTP Sent', `OTP sent to +91 ${phone}`);
    }, 1500);
  };

  const handleVerifyOTP = async () => {
    if (otp.length !== 6) {
      Alert.alert('Error', 'Please enter a valid 6-digit OTP');
      return;
    }

    setLoading(true);
    // Simulate API call
    setTimeout(() => {
      setLoading(false);
      if (otp === '123456') {
        setStep('profile');
      } else {
        Alert.alert('Error', 'Invalid OTP. Try 123456 for demo');
      }
    }, 1500);
  };

  const handleCompleteProfile = async () => {
    if (!name.trim() || !userType) {
      Alert.alert('Error', 'Please fill all fields');
      return;
    }

    setLoading(true);
    // Simulate API call
    setTimeout(() => {
      setLoading(false);
      if (userType === 'customer') {
        router.replace('/(customer)');
      } else {
        router.replace('/(worker)');
      }
    }, 1500);
  };

  const renderPhoneStep = () => (
    <View style={styles.stepContainer}>
      <View style={styles.iconContainer}>
        <Phone size={32} color={Colors.primary} strokeWidth={2} />
      </View>
      <Text style={styles.title}>Enter Your Phone Number</Text>
      <Text style={styles.subtitle}>We'll send you a verification code</Text>
      
      <View style={styles.phoneInputContainer}>
        <Text style={styles.countryCode}>+91</Text>
        <TextInput
          style={styles.phoneInput}
          value={phone}
          onChangeText={setPhone}
          placeholder="Enter phone number"
          keyboardType="phone-pad"
          maxLength={10}
        />
      </View>
      
      <Button
        title="Send OTP"
        onPress={handleSendOTP}
        loading={loading}
        style={styles.button}
      />
    </View>
  );

  const renderOTPStep = () => (
    <View style={styles.stepContainer}>
      <View style={styles.iconContainer}>
        <Phone size={32} color={Colors.primary} strokeWidth={2} />
      </View>
      <Text style={styles.title}>Verify OTP</Text>
      <Text style={styles.subtitle}>Enter the 6-digit code sent to +91 {phone}</Text>
      
      <TextInput
        style={styles.otpInput}
        value={otp}
        onChangeText={setOtp}
        placeholder="Enter OTP"
        keyboardType="number-pad"
        maxLength={6}
        textAlign="center"
      />
      
      <Button
        title="Verify OTP"
        onPress={handleVerifyOTP}
        loading={loading}
        style={styles.button}
      />

      <TouchableOpacity onPress={() => setStep('phone')}>
        <Text style={styles.backText}>Change Phone Number</Text>
      </TouchableOpacity>
    </View>
  );

  const renderProfileStep = () => (
    <View style={styles.stepContainer}>
      <View style={styles.iconContainer}>
        <User size={32} color={Colors.primary} strokeWidth={2} />
      </View>
      <Text style={styles.title}>Complete Your Profile</Text>
      <Text style={styles.subtitle}>Tell us a bit about yourself</Text>
      
      <TextInput
        style={styles.input}
        value={name}
        onChangeText={setName}
        placeholder="Enter your full name"
      />

      <Text style={styles.userTypeLabel}>I am a:</Text>
      <View style={styles.userTypeContainer}>
        <TouchableOpacity
          style={[
            styles.userTypeCard,
            userType === 'customer' && styles.selectedUserType
          ]}
          onPress={() => setUserType('customer')}
        >
          <Users size={24} color={userType === 'customer' ? Colors.white : Colors.primary} strokeWidth={2} />
          <Text style={[
            styles.userTypeTitle,
            userType === 'customer' && styles.selectedUserTypeText
          ]}>Customer</Text>
          <Text style={[
            styles.userTypeDesc,
            userType === 'customer' && styles.selectedUserTypeText
          ]}>I need services</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[
            styles.userTypeCard,
            userType === 'worker' && styles.selectedUserType
          ]}
          onPress={() => setUserType('worker')}
        >
          <Briefcase size={24} color={userType === 'worker' ? Colors.white : Colors.primary} strokeWidth={2} />
          <Text style={[
            styles.userTypeTitle,
            userType === 'worker' && styles.selectedUserTypeText
          ]}>Worker</Text>
          <Text style={[
            styles.userTypeDesc,
            userType === 'worker' && styles.selectedUserTypeText
          ]}>I provide services</Text>
        </TouchableOpacity>
      </View>
      
      <Button
        title="Complete Profile"
        onPress={handleCompleteProfile}
        loading={loading}
        style={styles.button}
      />
    </View>
  );

  return (
    <KeyboardAvoidingView 
      style={styles.container}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
    >
      <ScrollView contentContainerStyle={styles.scrollContainer}>
        <View style={styles.header}>
          <Text style={styles.logo}>WorkEase</Text>
        </View>

        {step === 'phone' && renderPhoneStep()}
        {step === 'otp' && renderOTPStep()}
        {step === 'profile' && renderProfileStep()}

        <View style={styles.footer}>
          <Text style={styles.footerText}>
            By continuing, you agree to our Terms of Service and Privacy Policy
          </Text>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  scrollContainer: {
    flexGrow: 1,
    paddingHorizontal: 24,
  },
  header: {
    alignItems: 'center',
    marginTop: 60,
    marginBottom: 40,
  },
  logo: {
    fontSize: 32,
    fontFamily: 'Poppins-Bold',
    color: Colors.primary,
  },
  stepContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  iconContainer: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: Colors.gray50,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 24,
  },
  title: {
    fontSize: 24,
    fontFamily: 'Poppins-SemiBold',
    color: Colors.textPrimary,
    textAlign: 'center',
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: Colors.textSecondary,
    textAlign: 'center',
    marginBottom: 32,
    lineHeight: 24,
  },
  phoneInputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: Colors.border,
    borderRadius: 12,
    backgroundColor: Colors.white,
    marginBottom: 24,
    paddingHorizontal: 16,
  },
  countryCode: {
    fontSize: 16,
    fontFamily: 'Inter-Medium',
    color: Colors.textPrimary,
    paddingRight: 12,
    borderRightWidth: 1,
    borderRightColor: Colors.border,
  },
  phoneInput: {
    flex: 1,
    height: 56,
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: Colors.textPrimary,
    paddingLeft: 12,
  },
  otpInput: {
    width: '100%',
    height: 56,
    borderWidth: 2,
    borderColor: Colors.border,
    borderRadius: 12,
    backgroundColor: Colors.white,
    fontSize: 18,
    fontFamily: 'Inter-SemiBold',
    color: Colors.textPrimary,
    marginBottom: 24,
    letterSpacing: 8,
  },
  input: {
    width: '100%',
    height: 56,
    borderWidth: 2,
    borderColor: Colors.border,
    borderRadius: 12,
    backgroundColor: Colors.white,
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: Colors.textPrimary,
    paddingHorizontal: 16,
    marginBottom: 24,
  },
  userTypeLabel: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: Colors.textPrimary,
    alignSelf: 'flex-start',
    marginBottom: 16,
  },
  userTypeContainer: {
    flexDirection: 'row',
    width: '100%',
    marginBottom: 32,
    gap: 12,
  },
  userTypeCard: {
    flex: 1,
    padding: 20,
    borderRadius: 16,
    borderWidth: 2,
    borderColor: Colors.border,
    backgroundColor: Colors.white,
    alignItems: 'center',
  },
  selectedUserType: {
    backgroundColor: Colors.primary,
    borderColor: Colors.primary,
  },
  userTypeTitle: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: Colors.textPrimary,
    marginTop: 8,
    marginBottom: 4,
  },
  userTypeDesc: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: Colors.textSecondary,
  },
  selectedUserTypeText: {
    color: Colors.white,
  },
  button: {
    width: '100%',
    marginBottom: 16,
  },
  backText: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: Colors.primary,
    textAlign: 'center',
  },
  footer: {
    paddingBottom: 24,
    paddingTop: 20,
  },
  footerText: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: Colors.textTertiary,
    textAlign: 'center',
    lineHeight: 18,
  },
});