import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Colors } from '@/constants/Colors';
import { Clock, MapPin, Phone, MessageCircle, Star } from 'lucide-react-native';

const BOOKING_TABS = ['Active', 'Completed', 'Cancelled'];

const MOCK_BOOKINGS = [
  {
    id: '1',
    service: 'Electrician',
    worker: 'Rajesh Kumar',
    status: 'ongoing',
    scheduledTime: '2024-01-15T14:00:00Z',
    location: 'Flat 301, Sai Residency, Kakinada',
    price: 350,
    rating: null,
    workerPhone: '+91 9876543210'
  },
  {
    id: '2',
    service: 'Plumber',
    worker: 'Suresh Reddy',
    status: 'completed',
    scheduledTime: '2024-01-10T10:00:00Z',
    location: 'House No. 45, Gandhi Nagar',
    price: 280,
    rating: 4.5,
    workerPhone: '+91 9876543211'
  },
  {
    id: '3',
    service: 'AC Technician',
    worker: 'Venkat Rao',
    status: 'cancelled',
    scheduledTime: '2024-01-08T16:00:00Z',
    location: 'Office 12, Business Park',
    price: 500,
    rating: null,
    workerPhone: '+91 9876543212'
  }
];

export default function BookingsScreen() {
  const [activeTab, setActiveTab] = useState('Active');

  const getFilteredBookings = () => {
    switch (activeTab) {
      case 'Active':
        return MOCK_BOOKINGS.filter(b => ['pending', 'accepted', 'ongoing'].includes(b.status));
      case 'Completed':
        return MOCK_BOOKINGS.filter(b => b.status === 'completed');
      case 'Cancelled':
        return MOCK_BOOKINGS.filter(b => b.status === 'cancelled');
      default:
        return MOCK_BOOKINGS;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending':
        return Colors.warning;
      case 'accepted':
      case 'ongoing':
        return Colors.info;
      case 'completed':
        return Colors.success;
      case 'cancelled':
        return Colors.error;
      default:
        return Colors.textSecondary;
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'pending':
        return 'Pending';
      case 'accepted':
        return 'Accepted';
      case 'ongoing':
        return 'In Progress';
      case 'completed':
        return 'Completed';
      case 'cancelled':
        return 'Cancelled';
      default:
        return status;
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-IN', {
      day: 'numeric',
      month: 'short',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const renderBookingCard = (booking: any) => (
    <View key={booking.id} style={styles.bookingCard}>
      <View style={styles.bookingHeader}>
        <View style={styles.serviceInfo}>
          <Text style={styles.serviceName}>{booking.service}</Text>
          <Text style={styles.workerName}>{booking.worker}</Text>
        </View>
        <View style={[styles.statusBadge, { backgroundColor: getStatusColor(booking.status) + '20' }]}>
          <Text style={[styles.statusText, { color: getStatusColor(booking.status) }]}>
            {getStatusText(booking.status)}
          </Text>
        </View>
      </View>

      <View style={styles.bookingDetails}>
        <View style={styles.detailRow}>
          <Clock size={16} color={Colors.textSecondary} strokeWidth={2} />
          <Text style={styles.detailText}>{formatDate(booking.scheduledTime)}</Text>
        </View>
        <View style={styles.detailRow}>
          <MapPin size={16} color={Colors.textSecondary} strokeWidth={2} />
          <Text style={styles.detailText} numberOfLines={2}>{booking.location}</Text>
        </View>
      </View>

      <View style={styles.bookingFooter}>
        <Text style={styles.price}>₹{booking.price}</Text>
        
        {booking.status === 'completed' && booking.rating && (
          <View style={styles.ratingContainer}>
            <Star size={14} color={Colors.accent} fill={Colors.accent} strokeWidth={0} />
            <Text style={styles.ratingText}>{booking.rating}</Text>
          </View>
        )}

        {['accepted', 'ongoing'].includes(booking.status) && (
          <View style={styles.actionButtons}>
            <TouchableOpacity style={styles.callButton}>
              <Phone size={16} color={Colors.success} strokeWidth={2} />
            </TouchableOpacity>
            <TouchableOpacity style={styles.chatButton}>
              <MessageCircle size={16} color={Colors.primary} strokeWidth={2} />
            </TouchableOpacity>
          </View>
        )}
      </View>
    </View>
  );

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>My Bookings</Text>
      </View>

      <View style={styles.tabContainer}>
        {BOOKING_TABS.map((tab) => (
          <TouchableOpacity
            key={tab}
            style={[styles.tab, activeTab === tab && styles.activeTab]}
            onPress={() => setActiveTab(tab)}
          >
            <Text style={[styles.tabText, activeTab === tab && styles.activeTabText]}>
              {tab}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        {getFilteredBookings().length > 0 ? (
          getFilteredBookings().map(renderBookingCard)
        ) : (
          <View style={styles.emptyState}>
            <Text style={styles.emptyTitle}>No bookings found</Text>
            <Text style={styles.emptyText}>
              {activeTab === 'Active' 
                ? 'You have no active bookings' 
                : `You have no ${activeTab.toLowerCase()} bookings`}
            </Text>
          </View>
        )}
        
        <View style={styles.bottomPadding} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.backgroundSecondary,
  },
  header: {
    backgroundColor: Colors.white,
    paddingHorizontal: 24,
    paddingVertical: 20,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  title: {
    fontSize: 24,
    fontFamily: 'Poppins-SemiBold',
    color: Colors.textPrimary,
  },
  tabContainer: {
    flexDirection: 'row',
    backgroundColor: Colors.white,
    paddingHorizontal: 24,
    paddingBottom: 8,
  },
  tab: {
    flex: 1,
    paddingVertical: 12,
    alignItems: 'center',
    borderBottomWidth: 2,
    borderBottomColor: 'transparent',
  },
  activeTab: {
    borderBottomColor: Colors.primary,
  },
  tabText: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: Colors.textSecondary,
  },
  activeTabText: {
    color: Colors.primary,
  },
  content: {
    flex: 1,
    paddingHorizontal: 24,
    paddingTop: 16,
  },
  bookingCard: {
    backgroundColor: Colors.white,
    borderRadius: 16,
    padding: 20,
    marginBottom: 16,
    shadowColor: Colors.black,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },
  bookingHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 16,
  },
  serviceInfo: {
    flex: 1,
  },
  serviceName: {
    fontSize: 18,
    fontFamily: 'Poppins-SemiBold',
    color: Colors.textPrimary,
    marginBottom: 4,
  },
  workerName: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: Colors.textSecondary,
  },
  statusBadge: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 12,
  },
  statusText: {
    fontSize: 12,
    fontFamily: 'Inter-SemiBold',
  },
  bookingDetails: {
    marginBottom: 16,
  },
  detailRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  detailText: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: Colors.textSecondary,
    marginLeft: 8,
    flex: 1,
  },
  bookingFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingTop: 16,
    borderTopWidth: 1,
    borderTopColor: Colors.border,
  },
  price: {
    fontSize: 18,
    fontFamily: 'Inter-Bold',
    color: Colors.primary,
  },
  ratingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  ratingText: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: Colors.textPrimary,
    marginLeft: 4,
  },
  actionButtons: {
    flexDirection: 'row',
    gap: 12,
  },
  callButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: Colors.success + '20',
    alignItems: 'center',
    justifyContent: 'center',
  },
  chatButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: Colors.primary + '20',
    alignItems: 'center',
    justifyContent: 'center',
  },
  emptyState: {
    alignItems: 'center',
    paddingVertical: 60,
  },
  emptyTitle: {
    fontSize: 18,
    fontFamily: 'Poppins-SemiBold',
    color: Colors.textPrimary,
    marginBottom: 8,
  },
  emptyText: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: Colors.textSecondary,
    textAlign: 'center',
  },
  bottomPadding: {
    height: 100,
  },
});