import { Service } from '@/types';

export const SERVICES: Service[] = [
  {
    id: '1',
    name: 'Electrician',
    icon: 'zap',
    description: 'Electrical repairs, wiring, fan installation',
    basePrice: 200,
    category: 'electrical'
  },
  {
    id: '2',
    name: 'Plumber',
    icon: 'wrench',
    description: 'Pipe repairs, tap fixing, bathroom fittings',
    basePrice: 250,
    category: 'plumbing'
  },
  {
    id: '3',
    name: 'Carpenter',
    icon: 'hammer',
    description: 'Furniture repair, door fixing, woodwork',
    basePrice: 300,
    category: 'carpentry'
  },
  {
    id: '4',
    name: 'AC Technician',
    icon: 'wind',
    description: 'AC installation, repair, servicing',
    basePrice: 400,
    category: 'ac'
  },
  {
    id: '5',
    name: 'House Cleaning',
    icon: 'sparkles',
    description: 'Deep cleaning, regular cleaning, sanitization',
    basePrice: 150,
    category: 'cleaning'
  },
  {
    id: '6',
    name: 'Painter',
    icon: 'palette',
    description: 'Wall painting, touch-ups, texture work',
    basePrice: 180,
    category: 'painting'
  }
];