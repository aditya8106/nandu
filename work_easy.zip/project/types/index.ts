export interface User {
  id: string;
  name: string;
  phone: string;
  email?: string;
  role: 'customer' | 'worker';
  avatar?: string;
  createdAt: Date;
}

export interface Service {
  id: string;
  name: string;
  icon: string;
  description: string;
  basePrice: number;
  category: 'electrical' | 'plumbing' | 'carpentry' | 'ac' | 'cleaning' | 'painting';
}

export interface Worker extends User {
  services: string[];
  rating: number;
  totalJobs: number;
  isAvailable: boolean;
  location: {
    latitude: number;
    longitude: number;
    address: string;
  };
  experience: number;
  verified: boolean;
  pricePerHour: number;
}

export interface Booking {
  id: string;
  customerId: string;
  workerId: string;
  serviceId: string;
  status: 'pending' | 'accepted' | 'ongoing' | 'completed' | 'cancelled';
  scheduledTime: Date;
  location: {
    latitude: number;
    longitude: number;
    address: string;
  };
  description: string;
  price: number;
  paymentStatus: 'pending' | 'paid' | 'failed';
  rating?: number;
  review?: string;
  createdAt: Date;
}

export interface Chat {
  id: string;
  bookingId: string;
  messages: Message[];
}

export interface Message {
  id: string;
  senderId: string;
  text: string;
  timestamp: Date;
  type: 'text' | 'image' | 'location';
}